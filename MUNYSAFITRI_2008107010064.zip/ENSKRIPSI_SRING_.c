#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void enkripsi_baru(char *, char *, int );//prototype
void enkripsi_baru(char * data, char * arah, int pergeseran){
//fungsi mengubah kapital menjadi kecil
	int i;	
	for(i=0;i<sizeof(*data)/sizeof(int);i++){
		if(arah[i]>='A' && arah[i]<='Z' ){
			arah[i]=arah[i]+32;
		}
	}
	//fungsi membandingkan jika inputan menerima string kanan atau kiri
	if (strcmp(arah,"kanan")==0){
		for(i=0;i<strlen(data);i++){
			data[i]=data[i]+pergeseran;
		}
		
	}else if(strcmp(arah,"kiri")==0){
		for(i=0;i<strlen(data);i++){
			data[i]=data[i]-pergeseran;
		}
	}
}
int main(){
	char  string[255],geser[10];
	int i,besar;
	printf("masukkan string: ");
	scanf(" %[^\n]",string);
	for(i=0;i<sizeof(string)/sizeof(int);i++){
		if(string[i]>='A' && string[i]<='Z' ){
			string[i]=string[i]+32;
		}	
	}
	getchar();
	//melakukan perulangan jika karakter bukan diantara 0 sd 183
	do{
	printf("masukkan besar pergeseran karakter: ");
	scanf(" %d",&besar);
	getchar();
	}while(besar<0||besar>183);	
	//melakukan perulangan jika inputan bukan kanan dan kiri
	do{
	printf("arah pergeseran karakter (kanan/kiri): ");
	scanf(" %s",geser);
	getchar();

	for(i=0;i<strlen(geser);i++){
		if(geser[i]>='A' && geser[i]<='Z' ){
			geser[i]=geser[i]+32;
		}
	}
    }while(strcmp(geser,"kanan")!=0 && strcmp(geser,"kiri")!=0 );
    //memanggil fungsi enkripsi_baru
    enkripsi_baru(  string,   geser,  besar);
    //mencetak hasil enkripsi
	printf("hasil enskripsi: ");
	for(i=0;i<strlen(string);i++){
			printf("%c",string[i]);
	}
	return 0;
}

